import pandas as pd
import numpy as np
import movie_list as ml


total_movies = pd.read_csv('genres.csv')

def get_genre_recommendations(genre):
    movie_dict = {rank : movie
                  for rank, movie in enumerate(total_movies[total_movies['genres'].str.contains(genre)].head(15)['title'].to_numpy().tolist(), 1)}
    return movie_dict

#if __name__ == '__main__':
    #print("Genres List: animation, news, action, history, family, \
#thriller, fantasy, horror, music, mystery, war, \
#reality-tv, drama, game-show, talk-show, musical, \
#crime, romance, biography, comedy, horror, adventure, \
#sci-fi, sport, adult, western, film-noir, sport")
    #genre = input("Enter a genre: ")

    #movie_dict = {rank : movie
                  #for rank, movie in enumerate(total_movies[total_movies['genres'].str.contains(genre)].head(15)['title'].to_numpy().tolist(), 1)}

    #print(get_genre_recommendations(genre))
